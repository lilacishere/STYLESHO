const jwt = require('jsonwebtoken');

// Ensure this secret matches the one in auth.js
const JWT_SECRET = 'your_jwt_secret_key'; // Replace 'your_jwt_secret_key' with your actual secret key

function verifyToken(req, res, next) {
    // Log the incoming Authorization header for debugging
    console.log("Authorization Header:", req.header('Authorization'));

    // Extract the token from the Authorization header
    const token = req.header('Authorization')?.replace('Bearer ', '').trim();
    console.log("Extracted Token:", token); // Log the token after extraction

    // If no token is provided, return an error
    if (!token) {
        return res.status(401).json({ message: 'Access denied. No token provided.' });
    }

    try {
        // Verify the token using JWT_SECRET
        const decoded = jwt.verify(token, JWT_SECRET);
        console.log("Token Decoded Successfully:", decoded); // Log decoded payload
        req.user = decoded; // Attach decoded user info to req.user
        next(); // Proceed to the next middleware or route handler
    } catch (error) {
        // Log error if token verification fails
        console.error("Token Verification Failed:", error.message);
        res.status(400).json({ message: 'Invalid token.' });
    }
}

module.exports = verifyToken;


