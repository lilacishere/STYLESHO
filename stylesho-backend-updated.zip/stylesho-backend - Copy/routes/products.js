const express = require('express');
const router = express.Router();
const verifyToken = require('../middleware/verifyToken'); // Ensure verifyToken.js is in middleware
const Product = require('../models/Product'); // Ensure Product model is defined in models/Product.js

// Create a new product (Protected Route)
router.post('/', verifyToken, async (req, res) => {
    const { name, description, price } = req.body;
    const brandId = req.user.userId; // Use the userId from the decoded token

    try {
        const product = new Product({ name, description, price, brandId });
        await product.save();
        res.status(201).json({ message: 'Product created successfully', product });
    } catch (error) {
        console.error('Error creating product:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Get all products for the authenticated brand (Protected Route)
router.get('/', verifyToken, async (req, res) => {
    try {
        const products = await Product.find({ brandId: req.user.userId });
        res.json(products);
    } catch (error) {
        console.error('Error fetching products:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Update a product by ID (Protected Route)
router.put('/:id', verifyToken, async (req, res) => {
    const { id } = req.params;
    const { name, description, price } = req.body;

    try {
        const product = await Product.findOneAndUpdate(
            { _id: id, brandId: req.user.userId },
            { name, description, price },
            { new: true }
        );

        if (!product) return res.status(404).json({ message: 'Product not found' });
        res.json({ message: 'Product updated successfully', product });
    } catch (error) {
        console.error('Error updating product:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Delete a product by ID (Protected Route)
router.delete('/:id', verifyToken, async (req, res) => {
    const { id } = req.params;

    try {
        const product = await Product.findOneAndDelete({ _id: id, brandId: req.user.userId });
        if (!product) return res.status(404).json({ message: 'Product not found' });

        res.json({ message: 'Product deleted successfully' });
    } catch (error) {
        console.error('Error deleting product:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;


