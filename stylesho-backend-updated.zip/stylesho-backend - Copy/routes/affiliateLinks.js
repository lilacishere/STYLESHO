
const express = require('express');
const router = express.Router();
const AffiliateLink = require('../models/AffiliateLink');
const Product = require('../models/Product');
const verifyToken = require('../middleware/verifyToken');

// Real-time earnings for influencers
router.get('/real-time-earnings', verifyToken, async (req, res) => {
    try {
        const affiliateLinks = await AffiliateLink.find({ influencer: req.user.userId });
        let totalEarnings = 0;
        let salesData = [];

        affiliateLinks.forEach(link => {
            link.conversions.forEach(conversion => {
                totalEarnings += conversion.influencerEarnings;
                salesData.push({
                    product: link.product,
                    saleAmount: conversion.saleAmount,
                    earnings: conversion.influencerEarnings,
                    timestamp: conversion.timestamp
                });
            });
        });

        res.json({
            message: 'Real-time earnings retrieved successfully',
            totalEarnings,
            salesData
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Brand performance tracking
router.get('/brand-performance/:brandId', verifyToken, async (req, res) => {
    try {
        const products = await Product.find({ brandId: req.params.brandId });
        let brandPerformance = [];

        for (const product of products) {
            const affiliateLinks = await AffiliateLink.find({ product: product._id });
            let productSales = 0;
            let influencerPerformance = [];

            affiliateLinks.forEach(link => {
                let influencerSales = 0;
                link.conversions.forEach(conversion => {
                    productSales += conversion.saleAmount;
                    influencerSales += conversion.saleAmount;
                });
                influencerPerformance.push({
                    influencerId: link.influencer,
                    totalSales: influencerSales,
                });
            });

            brandPerformance.push({
                productId: product._id,
                productName: product.name,
                totalSales: productSales,
                influencerPerformance
            });
        }

        res.json({
            message: 'Brand performance data retrieved successfully',
            brandPerformance
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;
