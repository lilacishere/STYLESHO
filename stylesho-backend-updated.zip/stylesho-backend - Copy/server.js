const express = require('express');
const mongoose = require('mongoose');
const app = express();
const PORT = 5000;

// Middleware to parse JSON
app.use(express.json());

// MongoDB Connection
const DB_URI = 'mongodb://localhost:27017/styleshoDB'; // Use your database name here
mongoose.connect(DB_URI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log("Connected to MongoDB"))
    .catch(error => console.error("MongoDB connection error:", error));

// Simple route to confirm server is running
app.get('/', (req, res) => {
    res.send('Server and MongoDB are connected');
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
const authRoutes = require('./routes/auth');      
const productRoutes = require('./routes/products');

app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
















