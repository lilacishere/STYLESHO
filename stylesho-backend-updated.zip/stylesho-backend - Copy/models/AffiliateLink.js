
const mongoose = require('mongoose');

const affiliateLinkSchema = new mongoose.Schema({
    product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
    influencer: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    linkId: { type: String, unique: true, required: true },
    clicks: { type: Number, default: 0 },
    conversions: [
        {
            saleAmount: { type: Number, required: true },
            timestamp: { type: Date, default: Date.now },
            platformEarnings: { type: Number },
            influencerEarnings: { type: Number }
        }
    ],
    commissionRate: { type: Number, default: 0.12 },
    platformShare: { type: Number, default: 0.05 },
    influencerShare: { type: Number, default: 0.07 },
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('AffiliateLink', affiliateLinkSchema);
